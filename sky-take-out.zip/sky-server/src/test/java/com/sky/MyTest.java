package com.sky;

import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClientBuilder;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

//@SpringBootTest
public class MyTest {
    @Test
    public void testUp() throws FileNotFoundException {
        // Endpoint外网访问域名，以杭州为例。
        String endpoint = "https://oss-cn-beijing.aliyuncs.com";
        // accessKeyId 和 accessKeySecret 是先前创建用户生成的
        String accessKeyId = "LTAI5tBeZLpuUyc4hdoye7Wm";
        String accessKeySecret = "14D0qEWuhBI40oDlxuxxSssRDvg7vk";

        // 创建OSSClient实例。
        OSS ossClient = new OSSClientBuilder().build(endpoint, accessKeyId, accessKeySecret);

        // 上传文件流。
        InputStream inputStream = new FileInputStream("D:\\图片\\1.png");
        ossClient.putObject("com-linyubing", "1.png", inputStream);

        // 关闭OSSClient。
        ossClient.shutdown();
    }
}
